#pragma once
#include "LinkedList.h"


int lru(LinkedList* L);

int lruUpdate(LinkedList* L, int value);


