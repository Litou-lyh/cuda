#pragma once
#include "cuda.h"
#include "cuda_runtime.h"
//class Node {
//public:
//	__device__ Node(int val = 0);
//	__device__ ~Node();
//
//	int value;
//	Node* next;
//	Node* prev;
//	__device__ void connect(Node* n = nullptr);
//
//};
//
//
//class LinkedList{
//public:
//	__device__ LinkedList(int cap = 4);
//	__device__ ~LinkedList();
//	Node* head;
//	Node* tail;
//
//	__device__ int cap();
//	__device__ int len();
//	__device__ bool isEmpty();
//	__device__ bool isFull();
//	__device__ bool find(int value);
//	__device__ Node* remove(int value);
//	__device__ Node* pop();
//	__device__ bool push(Node* n);
//	__device__ void toString();
//private:
//	__device__ void setCap(int cap);
//	int capacity;
//	int length;
//};








